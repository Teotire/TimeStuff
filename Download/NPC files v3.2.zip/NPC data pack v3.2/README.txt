This data pack is made by Timethegamer. If you include this pack in your own project be so kind and credit me, Timethegamer, as the rightfull creator ot the NPCs.

Special thanks to G3neral Sparks for helping me fix some bugs.